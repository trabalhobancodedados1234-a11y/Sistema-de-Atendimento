-- v3__create_table_gamificacao.sql
-- Inovação: Gamificação do Sistema de Atendimento
-- Adiciona pontuações, conquistas, níveis e ranking para atendentes

-- Tabela de níveis disponíveis no sistema
CREATE TABLE IF NOT EXISTS nivel (
    id          SERIAL PRIMARY KEY,
    nome        VARCHAR(50) NOT NULL,
    descricao   VARCHAR(255),
    xp_minimo   INT NOT NULL DEFAULT 0,
    xp_maximo   INT,
    icone       VARCHAR(50),
    cor_hex     VARCHAR(7),
    criado_em   TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de tipos de conquistas possíveis
CREATE TABLE IF NOT EXISTS conquista (
    id          SERIAL PRIMARY KEY,
    nome        VARCHAR(100) NOT NULL,
    descricao   VARCHAR(255) NOT NULL,
    icone       VARCHAR(50),
    xp_recompensa INT NOT NULL DEFAULT 0,
    criterio    VARCHAR(50) NOT NULL,  -- ex: 'atendimentos_concluidos', 'avaliacao_media', 'sem_cancelamentos'
    valor_meta  INT NOT NULL,          -- quantidade necessária para desbloquear
    ativa       BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em   TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de pontuação e nível atual de cada atendente
CREATE TABLE IF NOT EXISTS atendente_gamificacao (
    id              SERIAL PRIMARY KEY,
    atendente_id    INT NOT NULL UNIQUE,
    xp_total        INT NOT NULL DEFAULT 0,
    nivel_id        INT NOT NULL,
    atendimentos_ok INT NOT NULL DEFAULT 0,   -- total concluídos com sucesso
    streak_dias     INT NOT NULL DEFAULT 0,   -- dias consecutivos com atendimento
    ultima_atividade DATE,
    atualizado_em   TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_gamif_atendente FOREIGN KEY (atendente_id) REFERENCES atendente (id),
    CONSTRAINT fk_gamif_nivel     FOREIGN KEY (nivel_id)     REFERENCES nivel (id)
);

-- Tabela de conquistas desbloqueadas por atendente
CREATE TABLE IF NOT EXISTS atendente_conquista (
    id              SERIAL PRIMARY KEY,
    atendente_id    INT NOT NULL,
    conquista_id    INT NOT NULL,
    desbloqueado_em TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_ac_atendente  FOREIGN KEY (atendente_id)  REFERENCES atendente (id),
    CONSTRAINT fk_ac_conquista  FOREIGN KEY (conquista_id)  REFERENCES conquista (id),
    CONSTRAINT uq_ac_unique     UNIQUE (atendente_id, conquista_id)
);

-- Tabela de avaliações de atendimento feitas pelos clientes
CREATE TABLE IF NOT EXISTS avaliacao_atendimento (
    id              SERIAL PRIMARY KEY,
    atendimento_id  INT NOT NULL UNIQUE,
    nota            INT NOT NULL CHECK (nota BETWEEN 1 AND 5),
    comentario      TEXT,
    criado_em       TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_aval_atendimento FOREIGN KEY (atendimento_id) REFERENCES atendimento (id)
);

-- Tabela de log de XP (histórico de pontos ganhos)
CREATE TABLE IF NOT EXISTS log_xp (
    id              SERIAL PRIMARY KEY,
    atendente_id    INT NOT NULL,
    xp_ganho        INT NOT NULL,
    motivo          VARCHAR(100) NOT NULL,  -- ex: 'atendimento_concluido', 'conquista', 'avaliacao_5estrelas'
    referencia_id   INT,                   -- id do atendimento ou conquista relacionada
    criado_em       TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_logxp_atendente FOREIGN KEY (atendente_id) REFERENCES atendente (id)
);
