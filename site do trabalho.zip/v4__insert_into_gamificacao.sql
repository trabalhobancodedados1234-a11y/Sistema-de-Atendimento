-- v4__insert_into_gamificacao.sql
-- Dados iniciais para o sistema de gamificação

-- Níveis do sistema (do mais baixo ao mais alto)
INSERT INTO nivel (nome, descricao, xp_minimo, xp_maximo, icone, cor_hex) VALUES
('Iniciante',    'Bem-vindo ao time! Deu os primeiros passos.',      0,    499,  '🌱', '#8BC34A'),
('Aprendiz',     'Já conhece as rotinas e está evoluindo.',          500,  1499, '⭐', '#FFC107'),
('Profissional', 'Demonstra competência e consistência.',            1500, 3499, '🔥', '#FF9800'),
('Especialista', 'Referência na equipe, excelência no atendimento.', 3500, 6999, '💎', '#2196F3'),
('Mestre',       'Nível máximo. Inspiração para todos.',             7000, NULL, '👑', '#9C27B0');

-- Conquistas disponíveis
INSERT INTO conquista (nome, descricao, icone, xp_recompensa, criterio, valor_meta) VALUES
('Primeira Vez',          'Realizou seu primeiro atendimento.',                   '🎯', 50,  'atendimentos_concluidos', 1),
('Dekassegui',            'Concluiu 10 atendimentos com sucesso.',                '🔟', 100, 'atendimentos_concluidos', 10),
('Centurião',             'Concluiu 100 atendimentos com sucesso.',               '💯', 500, 'atendimentos_concluidos', 100),
('Nota Máxima',           'Recebeu avaliação 5 estrelas em um atendimento.',      '⭐', 75,  'avaliacao_5estrelas',      1),
('Excelência',            'Manteve média de avaliação ≥ 4.5 por 30 atendimentos.','🏆', 300, 'media_alta',               30),
('Sem Falhas',            'Encerrou um mês sem nenhum atendimento cancelado.',    '✅', 200, 'mes_sem_cancelamento',     1),
('Maratonista',           'Atendeu por 7 dias consecutivos.',                     '📅', 150, 'streak_dias',              7),
('Presença Constante',    'Atendeu por 30 dias consecutivos.',                    '🗓️', 400, 'streak_dias',              30),
('Multitarefa',           'Atuou em 3 filas diferentes no mesmo mês.',            '🔀', 120, 'filas_diferentes',         3),
('Velocidade Relâmpago',  'Concluiu 5 atendimentos em menos de 10 min cada.',     '⚡', 180, 'atendimentos_rapidos',     5);

-- Pontuação inicial dos 4 atendentes (baseada nos atendimentos já inseridos)
-- Atendente 1 (MAT-001): realizou 3 atendimentos concluídos
INSERT INTO atendente_gamificacao (atendente_id, xp_total, nivel_id, atendimentos_ok, streak_dias, ultima_atividade)
VALUES (1, 350, 1, 3, 3, CURRENT_DATE);

-- Atendente 2 (MAT-002): realizou 1 atendimento concluído
INSERT INTO atendente_gamificacao (atendente_id, xp_total, nivel_id, atendimentos_ok, streak_dias, ultima_atividade)
VALUES (2, 120, 1, 1, 1, CURRENT_DATE);

-- Atendente 3 (MAT-003): realizou 1 atendimento concluído
INSERT INTO atendente_gamificacao (atendente_id, xp_total, nivel_id, atendimentos_ok, streak_dias, ultima_atividade)
VALUES (3, 120, 1, 1, 1, CURRENT_DATE - INTERVAL '1 day');

-- Atendente 4 (MAT-004): realizou 1 atendimento concluído
INSERT INTO atendente_gamificacao (atendente_id, xp_total, nivel_id, atendimentos_ok, streak_dias, ultima_atividade)
VALUES (4, 120, 1, 1, 1, CURRENT_DATE);

-- Avaliações de atendimentos concluídos
INSERT INTO avaliacao_atendimento (atendimento_id, nota, comentario) VALUES
(1, 5, 'Atendimento excelente, muito rápido e eficiente!'),
(2, 4, 'Ótimo suporte, resolveu minha dúvida.'),
(3, 3, 'Atendimento ok, mas poderia ser mais ágil.'),
(4, 5, 'Perfeito! Resolvido em minutos pelo WhatsApp.');

-- Log de XP dos atendimentos
INSERT INTO log_xp (atendente_id, xp_ganho, motivo, referencia_id) VALUES
(1, 100, 'atendimento_concluido', 1),
(1, 150, 'avaliacao_5estrelas',   1),
(1, 100, 'atendimento_concluido', 5),
(2, 100, 'atendimento_concluido', 2),
(2, 50,  'avaliacao_4estrelas',   2),
(3, 100, 'atendimento_concluido', 3),
(4, 100, 'atendimento_concluido', 4),
(4, 150, 'avaliacao_5estrelas',   4);

-- Conquistas desbloqueadas (Primeira Vez = conquista id 1)
INSERT INTO atendente_conquista (atendente_id, conquista_id) VALUES
(1, 1),  -- atendente 1 desbloqueou "Primeira Vez"
(2, 1),  -- atendente 2 desbloqueou "Primeira Vez"
(3, 1),  -- atendente 3 desbloqueou "Primeira Vez"
(4, 1);  -- atendente 4 desbloqueou "Primeira Vez"
