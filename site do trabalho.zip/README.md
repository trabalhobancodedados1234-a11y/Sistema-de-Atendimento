# Sistema-de-Atendimento

## 📌 Tema
Sistema de Atendimento com **Gamificação**

---

## 🎯 Objetivo Geral
Desenvolver um sistema capaz de gerenciar o fluxo de atendimentos de uma empresa, permitindo o controle eficiente de filas, cadastro de clientes e atendentes, além do registro detalhado de cada atendimento realizado (data, hora, responsável e cliente atendido). O sistema busca otimizar o tempo de espera, melhorar a organização e aumentar a qualidade do atendimento.

Na **Fase 3**, o projeto foi expandido com um módulo de **Gamificação**, adicionando pontuação XP, níveis de evolução, conquistas desbloqueáveis e ranking entre atendentes para aumentar o engajamento e motivação da equipe.

---

## 🚀 Inovação: Gamificação

### Por que Gamificação?
Sistemas de atendimento tendem a ser repetitivos e desmotivantes. A gamificação transforma o trabalho diário em uma experiência mais engajante, recompensando boas práticas como:
- Alto volume de atendimentos concluídos
- Avaliações positivas dos clientes
- Consistência (dias consecutivos de atividade)
- Diversidade de filas atendidas

### Elementos implementados

| Elemento | Descrição |
|---|---|
| **XP (Pontos de Experiência)** | Cada atendimento concluído, avaliação positiva ou conquista gera XP |
| **Níveis** | 5 níveis: Iniciante → Aprendiz → Profissional → Especialista → Mestre |
| **Conquistas** | 10 badges desbloqueáveis por critérios específicos |
| **Ranking** | Classificação semanal/mensal dos atendentes por XP |
| **Avaliação** | Clientes avaliam de 1 a 5 estrelas, gerando XP bônus |
| **Streak** | Dias consecutivos de atividade com bônus progressivo |

### Ganho de XP por ação

| Ação | XP |
|---|---|
| Atendimento concluído | +100 |
| Avaliação 5 estrelas | +150 |
| Avaliação 4 estrelas | +50 |
| Conquista desbloqueada | Variável (50 a 500 XP) |
| Streak 7 dias | +150 |

---

## 👥 Público-Alvo
O sistema é voltado para empresas e organizações que realizam atendimentos ao público, como bancos, clínicas, repartições públicas, lojas e centrais de suporte. Também atende gestores e atendentes que precisam organizar e acompanhar o fluxo de clientes de forma prática e eficiente.

---

## 👨‍💻 Alunos
- Carlos Eduardo Passos Silva
- Eduardo Micael Saraiva Maia
- Joaquim Camillo pereira neto
- Lucas Gabriel Barreto Oliveira
- Renato Luiz

---

## 🗃️ Modelo de Dados (Atualizado — Fase 3)

```mermaid
erDiagram
  PESSOA {
    int id PK
    string nome
    string email
    string telefone
    string cpf
    date data_nasc
    boolean ativo
    timestamp criado_em
  }
  ATENDENTE {
    int id PK
    int pessoa_id FK
    string matricula
    enum turno
    boolean disponivel
    boolean ativo
    timestamp criado_em
  }
  CLIENTE {
    int id PK
    int pessoa_id FK
    string codigo
    enum tipo
    string cnpj
    boolean ativo
    timestamp criado_em
  }
  FILA {
    int id PK
    string nome
    string descricao
    enum tipo
    int capacidade_maxima
    int tempo_espera_max_min
    boolean ativa
    timestamp criado_em
  }
  ATENDENTE_FILA {
    int id PK
    int atendente_id FK
    int fila_id FK
    boolean principal
    timestamp associado_em
    timestamp desassociado_em
  }
  ATENDIMENTO {
    int id PK
    int fila_id FK
    int atendente_id FK
    int cliente_id FK
    timestamp data_hora_inicio
    timestamp data_hora_fim
    enum status
    enum canal
    text observacao
    timestamp criado_em
  }
  NIVEL {
    int id PK
    string nome
    string descricao
    int xp_minimo
    int xp_maximo
    string icone
    string cor_hex
    timestamp criado_em
  }
  CONQUISTA {
    int id PK
    string nome
    string descricao
    string icone
    int xp_recompensa
    string criterio
    int valor_meta
    boolean ativa
    timestamp criado_em
  }
  ATENDENTE_GAMIFICACAO {
    int id PK
    int atendente_id FK
    int xp_total
    int nivel_id FK
    int atendimentos_ok
    int streak_dias
    date ultima_atividade
    timestamp atualizado_em
  }
  ATENDENTE_CONQUISTA {
    int id PK
    int atendente_id FK
    int conquista_id FK
    timestamp desbloqueado_em
  }
  AVALIACAO_ATENDIMENTO {
    int id PK
    int atendimento_id FK
    int nota
    text comentario
    timestamp criado_em
  }
  LOG_XP {
    int id PK
    int atendente_id FK
    int xp_ganho
    string motivo
    int referencia_id
    timestamp criado_em
  }

  PESSOA            ||--o| ATENDENTE           : "pode ser atendente"
  PESSOA            ||--o| CLIENTE             : "pode ser cliente"
  ATENDENTE         ||--o{ ATENDENTE_FILA      : "associado a"
  FILA              ||--o{ ATENDENTE_FILA      : "possui"
  FILA              ||--o{ ATENDIMENTO         : "recebe"
  ATENDENTE         ||--o{ ATENDIMENTO         : "realiza"
  CLIENTE           ||--o{ ATENDIMENTO         : "e atendido em"
  ATENDIMENTO       ||--o| AVALIACAO_ATENDIMENTO: "recebe avaliacao"
  ATENDENTE         ||--|| ATENDENTE_GAMIFICACAO: "possui perfil gamer"
  NIVEL             ||--o{ ATENDENTE_GAMIFICACAO: "classifica"
  ATENDENTE         ||--o{ ATENDENTE_CONQUISTA : "desbloqueia"
  CONQUISTA         ||--o{ ATENDENTE_CONQUISTA : "e desbloqueada por"
  ATENDENTE         ||--o{ LOG_XP              : "acumula"
```

### Tabelas novas (Fase 3)

| Tabela | Descrição |
|---|---|
| `nivel` | Níveis disponíveis no sistema (Iniciante ao Mestre) |
| `conquista` | Badges desbloqueáveis com critérios e recompensa em XP |
| `atendente_gamificacao` | XP total, nível atual e streak de cada atendente |
| `atendente_conquista` | Conquistas desbloqueadas por atendente (N:N) |
| `avaliacao_atendimento` | Avaliação 1–5 estrelas feita pelo cliente |
| `log_xp` | Histórico completo de pontos ganhos por atendente |

---

## 📁 Estrutura do Repositório

```
scripts/
├── v1__create_table_pessoa.sql
├── v1__create_table_cliente.sql
├── v1__create_table_atendente.sql
├── v1__create_table_fila.sql
├── v1__create_table_atendente_fila.sql
├── v1__create_table_atendimento.sql
├── v2__insert_into_pessoa.sql
├── v2__insert_into_cliente.sql
├── v2__insert_into_atendente.sql
├── v2__insert_into_fila.sql
├── v2__insert_into_atendente_fila.sql
├── v2__insert_into_atendimento.sql
├── v2__update_delete_validacao.sql
├── v3__create_table_gamificacao.sql     ← NOVO (Fase 3)
└── v4__insert_into_gamificacao.sql      ← NOVO (Fase 3)

telas/
├── login.html          ← Tela de login
├── dashboard.html      ← Tela principal com ranking e KPIs
├── pessoas.html        ← Gerenciamento de pessoas
└── atendimentos.html   ← Gerenciamento de atendimentos (Kanban)
```

### Convenção de nomes
```
[Versão]__[acao]_[descricao/objeto].sql
```
- `v1__` → DDL (estrutura)
- `v2__` → DML (dados originais)
- `v3__` → DDL gamificação (Fase 3)
- `v4__` → DML gamificação (Fase 3)

---

## 🖥️ Protótipo de Interface

O protótipo foi desenvolvido em HTML/CSS/JS puro, com 4 telas funcionais e navegação entre elas.

### Telas implementadas

| Tela | Arquivo | Descrição |
|---|---|---|
| Login | `telas/login.html` | Autenticação com seleção de papel (Atendente / Gestor) |
| Dashboard | `telas/dashboard.html` | KPIs, ranking de XP e conquistas da equipe |
| Pessoas | `telas/pessoas.html` | Tabela com busca, filtro, modal de cadastro e ações |
| Atendimentos | `telas/atendimentos.html` | Kanban por status, painel lateral com avaliação por estrelas e XP |

### Paleta e design
- Tema escuro (`#0B0F1A`) com accent laranja (`#F97316`) e azul (`#3B82F6`)
- Tipografia: **Syne** (headings) + **DM Sans** (corpo)
- Sidebar de navegação fixa com links entre telas
- Animações CSS (fade-in, float, barra de XP)

---

## 🚀 Como executar

### Pré-requisitos
- PostgreSQL instalado (versão 13 ou superior)
- Navegador moderno para os protótipos HTML

### Banco de dados (ordem de execução)

```bash
# DDL original
psql -U usuario -d banco -f scripts/v1__create_table_pessoa.sql
psql -U usuario -d banco -f scripts/v1__create_table_cliente.sql
psql -U usuario -d banco -f scripts/v1__create_table_atendente.sql
psql -U usuario -d banco -f scripts/v1__create_table_fila.sql
psql -U usuario -d banco -f scripts/v1__create_table_atendente_fila.sql
psql -U usuario -d banco -f scripts/v1__create_table_atendimento.sql

# DML original
psql -U usuario -d banco -f scripts/v2__insert_into_pessoa.sql
psql -U usuario -d banco -f scripts/v2__insert_into_cliente.sql
psql -U usuario -d banco -f scripts/v2__insert_into_atendente.sql
psql -U usuario -d banco -f scripts/v2__insert_into_fila.sql
psql -U usuario -d banco -f scripts/v2__insert_into_atendente_fila.sql
psql -U usuario -d banco -f scripts/v2__insert_into_atendimento.sql
psql -U usuario -d banco -f scripts/v2__update_delete_validacao.sql

# Gamificação (Fase 3)
psql -U usuario -d banco -f scripts/v3__create_table_gamificacao.sql
psql -U usuario -d banco -f scripts/v4__insert_into_gamificacao.sql
```

### Protótipos HTML
Abra `telas/login.html` no navegador e navegue entre as telas.

---

## 🛠️ Tecnologias
- **SGBD:** PostgreSQL 13+
- **Linguagem SQL:** DDL + DML
- **Protótipo:** HTML5 · CSS3 · JavaScript (vanilla)
- **Fontes:** Google Fonts (Syne + DM Sans)
