-- ============================================================
-- INOVAÇÃO: INTELIGÊNCIA DE DADOS
-- v4__insert_into_ia_tables.sql
-- Dados de exemplo para as tabelas de IA
-- ============================================================


-- ============================================================
-- ia_analise_atendimento — scores por atendimento
-- ============================================================
INSERT INTO ia_analise_atendimento
    (atendimento_id, score_ia, tempo_real_min, tempo_previsto_min, canal_sugerido,
     fator_tempo, fator_canal, fator_cancelamento, observacao_ia)
VALUES
-- Atendimento 1: concluído presencial, bom desempenho
(1, 92.00, 30, 25, 'presencial',
  -3.00, 5.00, 0.00,
  'Atendimento dentro do esperado. Canal presencial adequado ao perfil do cliente. Leve excesso de tempo.'),

-- Atendimento 2: concluído via chat, rápido
(2, 88.00, 15, 18, 'chat',
   3.00, 5.00, 0.00,
  'Tempo abaixo do previsto — boa performance. Canal chat ideal para dúvidas contratuais.'),

-- Atendimento 3: concluído por telefone, médio
(3, 74.00, 20, 15, 'telefone',
  -5.00, 4.00, -5.00,
  'Tempo 33% acima do previsto. Reclamações por telefone tendem a ser mais longas. Sugestão: oferecer canal escrito.'),

-- Atendimento 4: concluído via whatsapp, excelente
(4, 95.00, 10, 12, 'whatsapp',
   2.00, 5.00,  8.00,
  'Atendimento exemplar. Rápido, canal adequado e cliente recorrente sem histórico de problemas.'),

-- Atendimento 9: cancelado — baixíssimo score
(9, 12.00, 2, 20, 'presencial',
 -10.00, -3.00, -15.00,
  'Atendimento cancelado. Cliente com histórico de desistência. Sugestão: prioridade na fila ou contato proativo.');


-- ============================================================
-- ia_previsao_demanda — previsão por fila, dia e hora
-- (segunda-feira = 1, fila 1 = Presencial Geral)
-- ============================================================
INSERT INTO ia_previsao_demanda
    (fila_id, dia_semana, hora_inicio, hora_fim, quantidade_prevista, confianca, alerta_capacidade, valido_ate)
VALUES
-- Fila Presencial — segunda-feira (pico matutino + pico vespertino)
(1, 1, '08:00', '09:00', 12, 0.820, TRUE,  CURRENT_DATE + 30),
(1, 1, '09:00', '10:00', 9,  0.850, FALSE, CURRENT_DATE + 30),
(1, 1, '10:00', '11:00', 7,  0.870, FALSE, CURRENT_DATE + 30),
(1, 1, '11:00', '12:00', 8,  0.840, FALSE, CURRENT_DATE + 30),
(1, 1, '14:00', '15:00', 18, 0.910, TRUE,  CURRENT_DATE + 30),
(1, 1, '15:00', '16:00', 14, 0.890, FALSE, CURRENT_DATE + 30),
(1, 1, '16:00', '17:00', 10, 0.860, FALSE, CURRENT_DATE + 30),

-- Fila Virtual Suporte — segunda-feira
(2, 1, '08:00', '09:00', 5,  0.780, FALSE, CURRENT_DATE + 30),
(2, 1, '14:00', '15:00', 11, 0.820, FALSE, CURRENT_DATE + 30),
(2, 1, '16:00', '17:00', 8,  0.800, FALSE, CURRENT_DATE + 30),

-- Fila Híbrida Premium — terça-feira
(3, 2, '09:00', '10:00', 4,  0.750, FALSE, CURRENT_DATE + 30),
(3, 2, '14:00', '15:00', 7,  0.820, FALSE, CURRENT_DATE + 30),

-- Fila Telefônica — quarta-feira
(4, 3, '10:00', '11:00', 6,  0.760, FALSE, CURRENT_DATE + 30),
(4, 3, '14:00', '15:00', 9,  0.840, FALSE, CURRENT_DATE + 30);


-- ============================================================
-- ia_log_insights — insights gerados pelo módulo de IA
-- ============================================================
INSERT INTO ia_log_insights
    (tipo, severidade, fila_id, atendente_id, titulo, descricao, acao_sugerida, visualizado, expira_em)
VALUES
(
  'alerta_pico', 'critico', 1, NULL,
  'Pico previsto às 14h–15h na Fila Presencial Geral',
  'O modelo prevê aumento de 40% na demanda para o período 14h–15h com base nos últimos 30 dias. Atualmente há apenas 1 atendente alocado nesse horário.',
  'Alocar atendente adicional (MAT-002 ou MAT-004) na Fila Presencial das 13h30 às 15h30.',
  FALSE,
  NOW() + INTERVAL '6 hours'
),
(
  'desempenho_atendente', 'aviso', NULL, 3,
  'Atendente MAT-003 com tempo médio 34% acima da média',
  'O tempo médio do atendente MAT-003 (turno noite) é de 28 min, contra a média geral de 20 min. O modelo identifica atendimentos do canal telefone como principal fator.',
  'Verificar se MAT-003 necessita de capacitação ou redistribuição de fila. Considerar coaching sobre gestão de tempo no telefone.',
  FALSE,
  NOW() + INTERVAL '7 days'
),
(
  'eficiencia_fila', 'info', 3, 4,
  'Fila Híbrida Premium com alta eficiência — score médio 93',
  'A Fila Híbrida Premium registrou score IA médio de 93/100 nos últimos 7 dias. MAT-004 foi responsável por 80% dos atendimentos com excelente resultado.',
  'Compartilhar práticas de MAT-004 com os demais atendentes. Considerar replicar o modelo de fluxo da fila híbrida para a presencial.',
  TRUE,
  NOW() + INTERVAL '14 days'
),
(
  'padrao_cancelamento', 'aviso', 1, NULL,
  'Alto índice de cancelamento às segundas-feiras 8h–9h',
  'O modelo detectou que 23% dos cancelamentos ocorrem às segundas-feiras entre 8h e 9h. Causa provável: fila lotada antes da abertura sem sistema de senhas digitais.',
  'Implementar senha digital antecipada via WhatsApp para segunda-feira. Considerar abertura 30 min antes das 8h apenas para essa fila.',
  FALSE,
  NOW() + INTERVAL '30 days'
);
