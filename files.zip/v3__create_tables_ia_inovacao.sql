-- ============================================================
-- INOVAÇÃO: INTELIGÊNCIA DE DADOS
-- v3__create_table_ia_analise_atendimento.sql
-- v3__create_table_ia_previsao_demanda.sql
-- v3__create_table_ia_log_insights.sql
-- ============================================================

-- ============================================================
-- TABELA 1: ia_analise_atendimento
-- Score de qualidade calculado por IA para cada atendimento
-- ============================================================
CREATE TABLE IF NOT EXISTS ia_analise_atendimento (
    id                  SERIAL PRIMARY KEY,
    atendimento_id      INT NOT NULL,

    -- Score geral calculado pelo modelo (0–100)
    score_ia            NUMERIC(5,2) NOT NULL CHECK (score_ia BETWEEN 0 AND 100),

    -- Tempo real vs tempo previsto (em minutos)
    tempo_real_min      INT,
    tempo_previsto_min  INT,

    -- Canal sugerido pela IA para futuros atendimentos semelhantes
    canal_sugerido      VARCHAR(20) CHECK (canal_sugerido IN ('presencial', 'telefone', 'chat', 'whatsapp')),

    -- Fatores que impactaram o score
    fator_tempo         NUMERIC(5,2),   -- penalidade/bônus pelo tempo
    fator_canal         NUMERIC(5,2),   -- adequação do canal ao perfil do cliente
    fator_cancelamento  NUMERIC(5,2),   -- histórico de cancelamentos do cliente

    -- Observação gerada pelo modelo
    observacao_ia       TEXT,

    -- Versão do modelo utilizado
    modelo_versao       VARCHAR(50) NOT NULL DEFAULT 'ia_atendimento_v1',
    criado_em           TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_ia_analise_atendimento FOREIGN KEY (atendimento_id) REFERENCES atendimento (id)
);

COMMENT ON TABLE  ia_analise_atendimento                IS 'Análise gerada por IA para cada atendimento registrado.';
COMMENT ON COLUMN ia_analise_atendimento.score_ia       IS 'Score de qualidade do atendimento de 0 a 100.';
COMMENT ON COLUMN ia_analise_atendimento.canal_sugerido IS 'Canal recomendado pelo modelo para otimizar atendimentos similares.';


-- ============================================================
-- TABELA 2: ia_previsao_demanda
-- Previsão de volume de atendimentos por fila, hora e dia
-- ============================================================
CREATE TABLE IF NOT EXISTS ia_previsao_demanda (
    id                      SERIAL PRIMARY KEY,
    fila_id                 INT NOT NULL,

    -- Dia da semana: 0=domingo, 1=segunda, ..., 6=sábado
    dia_semana              INT NOT NULL CHECK (dia_semana BETWEEN 0 AND 6),

    -- Faixa horária (início e fim)
    hora_inicio             TIME NOT NULL,
    hora_fim                TIME NOT NULL,

    -- Quantidade prevista de atendimentos nessa faixa
    quantidade_prevista     INT NOT NULL CHECK (quantidade_prevista >= 0),

    -- Nível de confiança da previsão (0.0 a 1.0)
    confianca               NUMERIC(4,3) NOT NULL CHECK (confianca BETWEEN 0 AND 1),

    -- Alertas gerados automaticamente quando a demanda prevista
    -- ultrapassa X% da capacidade da fila
    alerta_capacidade       BOOLEAN NOT NULL DEFAULT FALSE,

    modelo_versao           VARCHAR(50) NOT NULL DEFAULT 'ia_atendimento_v1',
    criado_em               TIMESTAMP NOT NULL DEFAULT NOW(),
    valido_ate              DATE NOT NULL,   -- data de expiração da previsão

    CONSTRAINT fk_ia_previsao_fila FOREIGN KEY (fila_id) REFERENCES fila (id)
);

COMMENT ON TABLE  ia_previsao_demanda                    IS 'Previsão de volume de atendimentos por fila, dia e faixa horária.';
COMMENT ON COLUMN ia_previsao_demanda.confianca          IS 'Nível de confiança do modelo: 1.0 = 100% de certeza.';
COMMENT ON COLUMN ia_previsao_demanda.alerta_capacidade  IS 'TRUE quando a demanda prevista ultrapassa a capacidade máxima da fila.';


-- ============================================================
-- TABELA 3: ia_log_insights
-- Registro de insights/alertas gerados pelo módulo de IA
-- ============================================================
CREATE TABLE IF NOT EXISTS ia_log_insights (
    id              SERIAL PRIMARY KEY,

    -- Tipo do insight
    tipo            VARCHAR(30) NOT NULL CHECK (tipo IN (
                        'alerta_pico',
                        'desempenho_atendente',
                        'padrao_cancelamento',
                        'sugestao_canal',
                        'eficiencia_fila',
                        'outro'
                    )),

    -- Severidade
    severidade      VARCHAR(10) NOT NULL CHECK (severidade IN ('info', 'aviso', 'critico')),

    -- Entidades relacionadas (nullable — nem todo insight refere a uma entidade específica)
    fila_id         INT,
    atendente_id    INT,

    -- Título e descrição legível pelo usuário
    titulo          VARCHAR(200) NOT NULL,
    descricao       TEXT NOT NULL,

    -- Ação sugerida ao gestor
    acao_sugerida   TEXT,

    -- Se o gestor visualizou / tomou ação
    visualizado     BOOLEAN NOT NULL DEFAULT FALSE,
    acao_tomada     BOOLEAN NOT NULL DEFAULT FALSE,
    acao_descricao  TEXT,

    modelo_versao   VARCHAR(50) NOT NULL DEFAULT 'ia_atendimento_v1',
    criado_em       TIMESTAMP NOT NULL DEFAULT NOW(),
    expira_em       TIMESTAMP,   -- insights têm validade (ex: alerta de pico expira depois do período)

    CONSTRAINT fk_ia_insight_fila      FOREIGN KEY (fila_id)      REFERENCES fila (id),
    CONSTRAINT fk_ia_insight_atendente FOREIGN KEY (atendente_id) REFERENCES atendente (id)
);

COMMENT ON TABLE  ia_log_insights              IS 'Histórico de insights e alertas gerados pelo módulo de IA.';
COMMENT ON COLUMN ia_log_insights.tipo         IS 'Categoria do insight para filtragem no dashboard.';
COMMENT ON COLUMN ia_log_insights.severidade   IS 'info = informativo, aviso = atenção necessária, critico = ação imediata.';
COMMENT ON COLUMN ia_log_insights.expira_em    IS 'Data/hora em que o insight deixa de ser relevante.';


-- ============================================================
-- ÍNDICES DE PERFORMANCE
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_ia_analise_atendimento_id   ON ia_analise_atendimento (atendimento_id);
CREATE INDEX IF NOT EXISTS idx_ia_analise_score            ON ia_analise_atendimento (score_ia);
CREATE INDEX IF NOT EXISTS idx_ia_previsao_fila_dia        ON ia_previsao_demanda (fila_id, dia_semana);
CREATE INDEX IF NOT EXISTS idx_ia_previsao_alerta          ON ia_previsao_demanda (alerta_capacidade) WHERE alerta_capacidade = TRUE;
CREATE INDEX IF NOT EXISTS idx_ia_insights_tipo_sev        ON ia_log_insights (tipo, severidade);
CREATE INDEX IF NOT EXISTS idx_ia_insights_nao_visualizados ON ia_log_insights (visualizado) WHERE visualizado = FALSE;
